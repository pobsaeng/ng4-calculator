import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MetadataAppComponent } from './metadata-app.component';

describe('MetadataAppComponent', () => {
  let component: MetadataAppComponent;
  let fixture: ComponentFixture<MetadataAppComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MetadataAppComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MetadataAppComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
