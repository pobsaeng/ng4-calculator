import { Component, Input, OnInit, ElementRef, AfterViewInit, ViewChild, Renderer } from '@angular/core';
import { Calculator } from '../classes/Calculator';

@Component({
  selector: 'app-root',
  templateUrl: './metadata-app.component.html'
})

export class MetadataAppComponent implements OnInit, AfterViewInit {
  @ViewChild('val1') private val1El: ElementRef;
  @ViewChild('val2') private val2El: ElementRef;
  @ViewChild('result') private resultEl: ElementRef;
  @ViewChild('rdo') private rdoEl: ElementRef;

  ngAfterViewInit(): void {
    this.renderer.invokeElementMethod(this.val1El.nativeElement, 'focus');
    this.rdoEl.nativeElement.checked = true;
  }

  private calculator: Calculator;
  constructor(private renderer: Renderer) {
    this.calculator = new Calculator();
  }

  ngOnInit() { }

  public Items = [
    { prefix: "+" },
    { prefix: "-" },
    { prefix: "x" },
    { prefix: "/" },
  ];

  public clickedItem = { prefix: "" };
  onItemClicked(Item) {
    this.clickedItem = Item;
  }

  onCalculate() {
    this.calculator.calCulate(
      [...[this.val1El, this.val2El, this.clickedItem, this.resultEl]]
    );
  }

  onClear() {
    this.calculator.clear(
      [...[this.val1El, this.val2El, this.resultEl]]);
  }
}
