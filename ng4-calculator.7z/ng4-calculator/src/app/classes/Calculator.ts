import {ElementRef, Injectable } from '@angular/core';

export class Calculator {
    clear(aryObject) {
        aryObject[0].nativeElement.value = "";
        aryObject[1].nativeElement.value = "";
        aryObject[2].nativeElement.innerHTML = "";
    }
    calCulate(aryObject) {
        let a = aryObject[0].nativeElement.value;
        let b = aryObject[1].nativeElement.value;
        let prefix = aryObject[2].prefix;
        let resultEl = aryObject[3].nativeElement;

        if (a == "") { alert('Please enter number one!'); return; }
        if (b == "") { alert('Please enter number two!'); return; }
        if (prefix == "") { alert('Please select operator!'); return; }

        if (prefix == '+') {
            resultEl.innerHTML = parseInt(a) + parseInt(b);

        } else if (prefix == '-') {
            resultEl.innerHTML = parseInt(a) - parseInt(b);

        }
        else if (prefix == 'x') {
            resultEl.innerHTML = parseInt(a) * parseInt(b);

        }
        else if (prefix == '/') {
            resultEl.innerHTML = parseInt(a) / parseInt(b);

        }
    }
} 