import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';

import { MetadataAppComponent } from './metadata-app/metadata-app.component';

@NgModule({
  declarations: [
    MetadataAppComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpModule
  ],
  providers: [],
  bootstrap: [MetadataAppComponent]
})
export class AppModule { }
